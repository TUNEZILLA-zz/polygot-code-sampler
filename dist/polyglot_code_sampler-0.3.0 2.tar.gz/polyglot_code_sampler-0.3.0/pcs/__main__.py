"""
Entry point for running pcs as a module: python -m pcs
"""

from .cli import main

if __name__ == "__main__":
    main()
